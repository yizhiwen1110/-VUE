<template>
    <div class="tion">
        <to></to>
  <!-- 所有分类 -->
<div class="page">
<!-- 一个类 -->
<div class="aclass">
  <a href="#">
      <img src="http://img.wanmei.com/secretshop/sta/tj/20180606/2d8379e7d68e4a89a59efb6762d3986b.jpg" alt="">
      <p>特别限量</p> 
      </a>  
</div>

<div class="aclass">
  <a href="#">
      <img src="http://img.wanmei.com/secretshop/sta/tj/20180606/9e65b9d021444047b0eed8a9a7ad66ae.jpg" alt="">
      <p>游戏手办</p> 
      </a>  
</div>
<div class="aclass">
  <a href="#">
      <img src="http://img.wanmei.com/secretshop/sta/tj/20180321/ea9805e758454b53b8518a3de92f6a01.jpg" alt="">
      <p>主题服饰</p> 
      </a>  
</div>
<div class="aclass">
  <a href="#">
      <img src="http://img.wanmei.com/secretshop/sta/tj/20180606/23b560c38b2d4cd395fd6ada49d18aa9.jpg" alt="">
      <p>创意T恤</p> 
      </a>  
</div>
<div class="aclass">
  <a href="#">
      <img src="http://img.wanmei.com/secretshop/sta/tj/20180321/b15e15dad49047219ac1561013f1ee93.jpg" alt="">
      <p>毛绒玩具</p> 
      </a>  
</div>
<div class="aclass">
  <a href="#">
      <img src="http://img.wanmei.com/secretshop/sta/tj/20180606/d264a05beb6e44449fef53c741555c84.jpg" alt="">
      <p>生活用品</p> 
      </a>  
</div>
</div>
    </div>
</template>
<script>
import to from './datationto'
export default {
    data(){
        return{

        }
    },
    components:{
        'to':to
    }
}
</script>
<style>
.tion{
    background-color: #fff;
}
    .page{
        display: flex;
       flex-wrap: wrap;
    justify-content: space-between;
    }
    .aclass{
        margin-top:20px;
        margin-bottom:20px;  
        width: 50%;
    }
    .aclass img{
        width: 50%;

    }
</style>