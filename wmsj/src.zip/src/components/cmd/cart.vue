<template>
 <div class="ca">
        <!-- 头部 -->
     <div class="cart"  >
       <router-link to='./cmd'> <a href=""><img src="../../assets/返回.png" alt=""></a> </router-link>
        <!-- v-on:click="back" -->
        <div>我的购物车</div>
        <span class="btn"><button>整理</button></span>
     </div>
  <!-- 商品信息 -->
    <div class='mation'>
       <div class="box">
         <input type="checkbox">
       </div>
         <span class="Commoditydetails">商品信息</span>
         <span class="operation">操作</span>
    </div>

    <!-- 购物车商品 -->
    <div class="merchandise">
        <!-- 多选框 -->
        <div class="box">
            <input type="checkbox">
        </div>
        <!-- 商品信息 -->
        <div class="detail">
           <img style="width:30px;height:30px;" src="../../assets/3.png" alt="">
            <p class="words">
               <a href="">DOTA2- T恤 烫金拍拍（男女同款）</a>
               <span>￥139.00</span>
               <span>款式：L</span>
             </p>
        </div>
        <!-- 商品数量 -->
        <div class="Number">
 <button>-</button><span>0</span><button>+</button>
        </div>
    </div>

  <!-- 底部提交 -->
    <div class="Submission">
        <div class="Total">
            <span class="money">￥0.00</span>
            <br>
            商品：<span class="Number">0</span>
        </div>
        <a class="Order" href="">提交订单</a>
    </div>
 </div>
</template>
<script>
export default {
    data(){
        return{

        }
    },
    // methods:{
    //      back(){
    //     this.$router.go(-1);//返回上一层
    // },
    
}
</script>
<style>
input{
   width:17px;
    height:17px
}

/* 我的购物车头部样式 */
  .cart{
        display: flex;
        height: 50px;
        border-bottom:1px solid #d7d7d7; 
    }
     .cart a{
       width: 20%;
    padding: 10px;
     }
     .cart img{
         width: 60%;
         height: 90%;
     }
      .cart div{
      width: 230px;
      line-height: 50px;
      color: #323232;
      }
      .btn{
          flex: 1;
          padding-top:9px ;
      }
      /* 按钮样式 */
    .ca  button{
          background-color: #e32332;
          color:#fff  ;
        border-radius:8px ;
      }
      .mation{
          display: flex;
          height: 45px;
          border-bottom:2px solid #e4e4e4;
      }
      .box{
          width: 20%;
          line-height:47px ;
      }
      .Commoditydetails{
          width: 50%;
            line-height:45px ;
            color: #323232;
      }
    .operation{
        flex: 1;
       line-height:45px;
       color:#999;
       font-size: 14px;
    }
    /* 底部提交按钮 */
    .Submission{
        position: fixed;
        bottom: 0;
        left: 0;
        width: 100%;
        display: flex;
        height:50px ;
    }
    .Order{
    flex: 1;
    line-height: 50px;
    color: #fff;
    background-color: #e32332
    }
    .Total{
        width: 65%;
        text-align: left;
        padding-left:20px;
        background-color: #fff;
        color: #e32332;
        font-weight:700;
    }
    /* 商品信息样式 */
    .merchandise{
     display: flex;
     padding-top: 10px;
border-bottom:1px solid #e4e4e4; 
    }
   .detail{
       display: flex;
        width:55%; 
       height: 52px;
   }
   .words{
       padding-left:8px; 
       display: flex;
        flex-direction:column;
       color:#999;
       font-size: 5px;
       text-align: left;
     line-height: 15px;
   }
    .words a{
        color:#000;
           width: 100%;
    overflow: hidden; 
    }
   .Number{
   flex: 1;
   line-height:34px;
   }
   .Number button{
       background-color: #ddd;
       color:#666;
       border: 0
   }
 .Number span{
     margin: 0 6px 0 6px;
 }
</style>