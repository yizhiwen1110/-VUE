<template>
    <div class="datationto">
  <div class="datationtos"  >
<div>分类</div>
  </div>
    </div>
</template>
<script>
export default {
    data(){
        return{

        }
    }
}
</script>
<style>
    .datationtos{
        display: flex;
        height: 50px;
        border-bottom:1px solid #d7d7d7; 
    }
      .datationtos div{
      width: 100%;
      line-height: 50px;
      color: #323232;
      }
</style>